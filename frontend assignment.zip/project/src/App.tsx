import React from 'react';
import Calendar from './components/Calendar/Calendar';
import { EventProvider } from './contexts/EventContext';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';

function App() {
  return (
    <DndProvider backend={HTML5Backend}>
      <EventProvider>
        <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white">
          <header className="bg-gradient-to-r from-primary-600 to-accent-600 text-white py-6 px-6 shadow-lg">
            <h1 className="text-3xl font-bold tracking-tight">Event Calendar</h1>
            <p className="text-primary-100 mt-1">Organize your schedule with ease</p>
          </header>
          <main className="container mx-auto p-4 md:p-6 lg:p-8">
            <div className="backdrop-blur-sm bg-white/80 rounded-2xl shadow-xl overflow-hidden">
              <Calendar />
            </div>
          </main>
        </div>
      </EventProvider>
    </DndProvider>
  );
}

export default App;