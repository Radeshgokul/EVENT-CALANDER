import React, { useState } from 'react';
import CalendarHeader from './CalendarHeader';
import CalendarGrid from './CalendarGrid';
import EventModal from '../Event/EventModal';
import { ModalState } from '../../types';
import { useEvents } from '../../contexts/EventContext';
import { format } from 'date-fns';

const Calendar: React.FC = () => {
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [searchTerm, setSearchTerm] = useState<string>('');
  const { events } = useEvents();
  
  const [modalState, setModalState] = useState<ModalState>({
    isOpen: false,
    mode: 'add',
  });
  
  const handlePrevMonth = () => {
    setCurrentDate(prevDate => {
      const prevMonth = new Date(prevDate);
      prevMonth.setMonth(prevMonth.getMonth() - 1);
      return prevMonth;
    });
  };
  
  const handleNextMonth = () => {
    setCurrentDate(prevDate => {
      const nextMonth = new Date(prevDate);
      nextMonth.setMonth(nextMonth.getMonth() + 1);
      return nextMonth;
    });
  };
  
  const handleTodayClick = () => {
    setCurrentDate(new Date());
  };
  
  const handleDayClick = (date: Date) => {
    setModalState({
      isOpen: true,
      mode: 'add',
      date,
    });
  };
  
  const handleEventClick = (eventId: string) => {
    setModalState({
      isOpen: true,
      mode: 'view',
      eventId,
    });
  };
  
  const handleCloseModal = () => {
    setModalState({
      isOpen: false,
      mode: 'add',
    });
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const filteredEvents = searchTerm 
    ? events.filter(event => 
        event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.description.toLowerCase().includes(searchTerm.toLowerCase()))
    : events;

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-4 flex flex-col md:flex-row md:items-center justify-between border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-800 mb-2 md:mb-0">
          {format(currentDate, 'MMMM yyyy')}
        </h2>
        <div className="flex items-center space-x-2">
          <div className="relative">
            <input
              type="text"
              placeholder="Search events..."
              className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 w-full md:w-64"
              value={searchTerm}
              onChange={handleSearch}
            />
          </div>
        </div>
      </div>
      
      <CalendarHeader 
        currentDate={currentDate}
        onPrevMonth={handlePrevMonth}
        onNextMonth={handleNextMonth}
        onTodayClick={handleTodayClick}
      />
      
      <CalendarGrid 
        currentDate={currentDate}
        onDayClick={handleDayClick}
        onEventClick={handleEventClick}
        filteredEvents={filteredEvents}
      />
      
      {modalState.isOpen && (
        <EventModal
          modalState={modalState}
          onClose={handleCloseModal}
        />
      )}
    </div>
  );
};

export default Calendar;