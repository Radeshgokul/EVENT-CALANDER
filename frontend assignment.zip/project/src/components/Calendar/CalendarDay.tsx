import React from 'react';
import { CalendarDay as CalendarDayType } from '../../types';
import { format } from 'date-fns';
import EventItem from '../Event/EventItem';
import { useDrop } from 'react-dnd';
import { useEvents } from '../../contexts/EventContext';

interface CalendarDayProps {
  day: CalendarDayType;
  onDayClick: (date: Date) => void;
  onEventClick: (eventId: string) => void;
}

const CalendarDay: React.FC<CalendarDayProps> = ({
  day,
  onDayClick,
  onEventClick,
}) => {
  const { moveEvent, hasEventConflict } = useEvents();
  
  const [{ isOver, canDrop }, drop] = useDrop({
    accept: 'EVENT',
    drop: (item: { id: string }) => {
      moveEvent(item.id, day.date);
    },
    canDrop: (item: { id: string, date: Date }) => {
      return !hasEventConflict({ id: item.id, date: day.date }, item.id);
    },
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
      canDrop: !!monitor.canDrop(),
    }),
  });
  
  const handleDayClick = () => {
    onDayClick(day.date);
  };
  
  const handleEventClick = (
    e: React.MouseEvent<HTMLDivElement>,
    eventId: string
  ) => {
    e.stopPropagation();
    onEventClick(eventId);
  };
  
  const sortedEvents = [...day.events].sort((a, b) => 
    a.date.getTime() - b.date.getTime()
  );
  
  const MAX_VISIBLE_EVENTS = 3;
  const visibleEvents = sortedEvents.slice(0, MAX_VISIBLE_EVENTS);
  const hiddenEventsCount = sortedEvents.length - MAX_VISIBLE_EVENTS;
  
  return (
    <div
      ref={drop}
      className={`
        min-h-28 p-2 border-r border-b border-primary-100 transition-all duration-200
        ${!day.isCurrentMonth ? 'bg-gray-50/50' : 'hover:bg-primary-50/50'}
        ${day.isToday ? 'bg-primary-50/70' : ''}
        ${isOver && canDrop ? 'bg-success-50/70' : ''}
        ${isOver && !canDrop ? 'bg-error-50/70' : ''}
      `}
      onClick={handleDayClick}
    >
      <div className="flex justify-between items-start">
        <span
          className={`
            flex items-center justify-center w-7 h-7 text-sm font-medium rounded-full
            transition-colors duration-200
            ${day.isToday ? 'bg-primary-600 text-white shadow-sm' : ''}
            ${!day.isCurrentMonth ? 'text-gray-400' : 'text-gray-700'}
          `}
        >
          {format(day.date, 'd')}
        </span>
      </div>
      
      <div className="mt-2 space-y-1 overflow-y-auto max-h-32">
        {visibleEvents.map((event) => (
          <EventItem
            key={event.id}
            event={event}
            onClick={(e) => handleEventClick(e, event.id)}
          />
        ))}
        
        {hiddenEventsCount > 0 && (
          <div className="text-xs text-gray-500 bg-gray-100/80 px-2 py-1 rounded-md backdrop-blur-sm">
            +{hiddenEventsCount} more events
          </div>
        )}
      </div>
    </div>
  );
};

export default CalendarDay;