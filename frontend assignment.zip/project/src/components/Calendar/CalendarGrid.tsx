import React from 'react';
import CalendarDay from './CalendarDay';
import { CalendarDay as CalendarDayType, Event } from '../../types';
import { 
  startOfMonth, endOfMonth, startOfWeek, endOfWeek, 
  eachDayOfInterval, isSameMonth, isSameDay, format 
} from 'date-fns';
import { useEvents } from '../../contexts/EventContext';

interface CalendarGridProps {
  currentDate: Date;
  onDayClick: (date: Date) => void;
  onEventClick: (eventId: string) => void;
  filteredEvents: Event[];
}

const CalendarGrid: React.FC<CalendarGridProps> = ({
  currentDate,
  onDayClick,
  onEventClick,
  filteredEvents,
}) => {
  const { getEventsForDate } = useEvents();
  
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calendarStart = startOfWeek(monthStart);
  const calendarEnd = endOfWeek(monthEnd);
  
  const calendarDays: CalendarDayType[] = eachDayOfInterval({
    start: calendarStart,
    end: calendarEnd,
  }).map(date => {
    const isCurrentMonth = isSameMonth(date, currentDate);
    const isToday = isSameDay(date, new Date());
    
    // Get events for this day
    const dayEvents = getEventsForDate(date)
      .filter(event => filteredEvents.some(fe => fe.id === event.id));
    
    return {
      date,
      isCurrentMonth,
      isToday,
      events: dayEvents,
    };
  });
  
  // Create rows for the calendar (6 weeks maximum)
  const calendarRows: CalendarDayType[][] = [];
  let days: CalendarDayType[] = [];
  
  calendarDays.forEach((day, i) => {
    if (i % 7 === 0 && i > 0) {
      calendarRows.push(days);
      days = [];
    }
    days.push(day);
  });
  
  if (days.length > 0) {
    calendarRows.push(days);
  }
  
  return (
    <div className="grid grid-cols-7 border-t border-l border-gray-200">
      {calendarDays.map((day, index) => (
        <CalendarDay
          key={format(day.date, 'yyyy-MM-dd')}
          day={day}
          onDayClick={onDayClick}
          onEventClick={onEventClick}
        />
      ))}
    </div>
  );
};

export default CalendarGrid;