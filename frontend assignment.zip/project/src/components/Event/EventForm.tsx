import React, { useState, useEffect } from 'react';
import { EventFormData, Event, RecurrenceType, RecurrencePattern } from '../../types';
import { format } from 'date-fns';
import { v4 as uuidv4 } from 'uuid';

interface EventFormProps {
  initialDate?: Date;
  initialEvent?: Event | null;
  onSubmit: (formData: EventFormData) => void;
}

const EVENT_COLORS = [
  { label: 'Blue', value: '#3b82f6' },
  { label: 'Green', value: '#10b981' },
  { label: 'Red', value: '#ef4444' },
  { label: 'Yellow', value: '#f59e0b' },
  { label: 'Purple', value: '#8b5cf6' },
  { label: 'Pink', value: '#ec4899' },
];

const EventForm: React.FC<EventFormProps> = ({
  initialDate,
  initialEvent,
  onSubmit,
}) => {
  const [formData, setFormData] = useState<EventFormData>({
    id: initialEvent?.id || uuidv4(),
    title: initialEvent?.title || '',
    date: initialEvent ? format(initialEvent.date, 'yyyy-MM-dd') : initialDate ? format(initialDate, 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd'),
    time: initialEvent ? format(initialEvent.date, 'HH:mm') : '09:00',
    endTime: initialEvent?.endTime ? format(initialEvent.endTime, 'HH:mm') : '10:00',
    description: initialEvent?.description || '',
    color: initialEvent?.color || EVENT_COLORS[0].value,
    recurrence: initialEvent?.recurrence || { type: 'none' },
  });
  
  const [showRecurringOptions, setShowRecurringOptions] = useState<boolean>(
    initialEvent?.isRecurring || false
  );
  
  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleRecurrenceTypeChange = (
    e: React.ChangeEvent<HTMLSelectElement>
  ) => {
    const type = e.target.value as RecurrenceType;
    
    let recurrence: RecurrencePattern = { type };
    
    if (type === 'weekly') {
      recurrence.daysOfWeek = [new Date(formData.date).getDay()];
    } else if (type === 'custom') {
      recurrence.interval = 1;
    }
    
    setFormData((prev) => ({
      ...prev,
      recurrence,
    }));
  };
  
  const handleRecurrenceIntervalChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const interval = parseInt(e.target.value);
    setFormData((prev) => ({
      ...prev,
      recurrence: {
        ...prev.recurrence,
        interval,
      },
    }));
  };
  
  const handleDayOfWeekToggle = (dayIndex: number) => {
    const currentDays = formData.recurrence.daysOfWeek || [];
    const newDays = currentDays.includes(dayIndex)
      ? currentDays.filter((day) => day !== dayIndex)
      : [...currentDays, dayIndex];
    
    setFormData((prev) => ({
      ...prev,
      recurrence: {
        ...prev.recurrence,
        daysOfWeek: newDays,
      },
    }));
  };
  
  const handleColorSelect = (color: string) => {
    setFormData((prev) => ({ ...prev, color }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Event Title
        </label>
        <input
          type="text"
          name="title"
          value={formData.title}
          onChange={handleInputChange}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
          required
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Date
          </label>
          <input
            type="date"
            name="date"
            value={formData.date}
            onChange={handleInputChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
            required
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Start Time
          </label>
          <input
            type="time"
            name="time"
            value={formData.time}
            onChange={handleInputChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
            required
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            End Time
          </label>
          <input
            type="time"
            name="endTime"
            value={formData.endTime}
            onChange={handleInputChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
          />
        </div>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Description
        </label>
        <textarea
          name="description"
          value={formData.description}
          onChange={handleInputChange}
          rows={3}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Event Color
        </label>
        <div className="flex flex-wrap gap-2">
          {EVENT_COLORS.map((color) => (
            <button
              key={color.value}
              type="button"
              className={`w-8 h-8 rounded-full transition-transform ${
                formData.color === color.value
                  ? 'ring-2 ring-offset-2 ring-gray-400 scale-110'
                  : ''
              }`}
              style={{ backgroundColor: color.value }}
              onClick={() => handleColorSelect(color.value)}
              title={color.label}
            />
          ))}
        </div>
      </div>
      
      <div>
        <div className="flex items-center">
          <input
            type="checkbox"
            id="isRecurring"
            checked={showRecurringOptions}
            onChange={(e) => setShowRecurringOptions(e.target.checked)}
            className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
          />
          <label
            htmlFor="isRecurring"
            className="ml-2 block text-sm font-medium text-gray-700"
          >
            Recurring Event
          </label>
        </div>
        
        {showRecurringOptions && (
          <div className="mt-3 space-y-3 p-3 bg-gray-50 rounded-md animate-fade-in">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Recurrence Type
              </label>
              <select
                value={formData.recurrence.type}
                onChange={handleRecurrenceTypeChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
              >
                <option value="none">None</option>
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="custom">Custom</option>
              </select>
            </div>
            
            {formData.recurrence.type === 'weekly' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Repeat on
                </label>
                <div className="flex flex-wrap gap-1">
                  {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, index) => (
                    <button
                      key={index}
                      type="button"
                      className={`w-8 h-8 rounded-full ${
                        formData.recurrence.daysOfWeek?.includes(index)
                          ? 'bg-primary-500 text-white'
                          : 'bg-gray-200 text-gray-700'
                      }`}
                      onClick={() => handleDayOfWeekToggle(index)}
                    >
                      {day}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {formData.recurrence.type === 'custom' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Repeat every
                </label>
                <div className="flex items-center">
                  <input
                    type="number"
                    min="1"
                    value={formData.recurrence.interval || 1}
                    onChange={handleRecurrenceIntervalChange}
                    className="w-16 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                  <span className="ml-2 text-gray-700">
                    {formData.recurrence.type === 'daily'
                      ? 'days'
                      : formData.recurrence.type === 'weekly'
                      ? 'weeks'
                      : formData.recurrence.type === 'monthly'
                      ? 'months'
                      : 'days'}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
      
      <div className="flex justify-end space-x-2 pt-3 border-t border-gray-200">
        <button
          type="submit"
          className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
        >
          {initialEvent ? 'Update Event' : 'Add Event'}
        </button>
      </div>
    </form>
  );
};

export default EventForm;