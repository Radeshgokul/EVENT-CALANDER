import React from 'react';
import { Event } from '../../types';
import { format } from 'date-fns';
import { useDrag } from 'react-dnd';

interface EventItemProps {
  event: Event;
  onClick: (e: React.MouseEvent<HTMLDivElement>) => void;
}

const EventItem: React.FC<EventItemProps> = ({ event, onClick }) => {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'EVENT',
    item: { id: event.id, date: event.date },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }));
  
  const displayTime = format(event.date, 'h:mm a');
  
  return (
    <div
      ref={drag}
      className={`
        group px-3 py-1.5 rounded-lg cursor-pointer
        transition-all duration-200 animate-bounce-in
        hover:shadow-event hover:translate-y-[-1px]
        ${isDragging ? 'opacity-50' : 'opacity-100'}
      `}
      style={{ 
        backgroundColor: `${event.color}15`,
        borderLeft: `3px solid ${event.color}` 
      }}
      onClick={onClick}
    >
      <div className="font-medium truncate text-gray-800 group-hover:text-gray-900">
        {event.title}
      </div>
      <div className="text-xs text-gray-500 group-hover:text-gray-700">
        {displayTime}
      </div>
      {event.isRecurring && (
        <div className="text-xs text-gray-500 flex items-center mt-0.5 group-hover:text-gray-700">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          {event.recurrence.type}
        </div>
      )}
    </div>
  );
};

export default EventItem;