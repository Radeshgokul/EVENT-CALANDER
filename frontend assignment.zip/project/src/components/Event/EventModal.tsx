import React, { useState, useEffect } from 'react';
import { ModalState, Event, EventFormData } from '../../types';
import { X } from 'lucide-react';
import { useEvents } from '../../contexts/EventContext';
import EventForm from './EventForm';
import EventView from './EventView';
import { format } from 'date-fns';

interface EventModalProps {
  modalState: ModalState;
  onClose: () => void;
}

const EventModal: React.FC<EventModalProps> = ({ modalState, onClose }) => {
  const { events, addEvent, updateEvent, deleteEvent } = useEvents();
  const [currentEvent, setCurrentEvent] = useState<Event | null>(null);
  const [mode, setMode] = useState<'view' | 'edit' | 'add'>(modalState.mode);

  useEffect(() => {
    if (modalState.eventId) {
      const event = events.find((e) => e.id === modalState.eventId);
      if (event) {
        setCurrentEvent(event);
      }
    }
    setMode(modalState.mode);
  }, [modalState, events]);

  const handleSubmit = (formData: EventFormData) => {
    const [hours, minutes] = formData.time.split(':').map(Number);
    const eventDate = new Date(formData.date);
    eventDate.setHours(hours);
    eventDate.setMinutes(minutes);

    let endTime;
    if (formData.endTime) {
      const [endHours, endMinutes] = formData.endTime.split(':').map(Number);
      endTime = new Date(formData.date);
      endTime.setHours(endHours);
      endTime.setMinutes(endMinutes);

      // Ensure endTime is after the start time
      if (endTime <= eventDate) {
        alert('End time must be after start time');
        return;
      }
    }

    const event: Event = {
      id: formData.id || modalState.eventId || '',
      title: formData.title,
      date: eventDate,
      endTime: endTime,
      description: formData.description,
      color: formData.color,
      recurrence: formData.recurrence,
      isRecurring: formData.recurrence.type !== 'none',
    };

    if (mode === 'add') {
      addEvent(event);
    } else if (mode === 'edit') {
      updateEvent(event);
    }

    onClose();
  };

  const handleDelete = () => {
    if (currentEvent) {
      if (window.confirm('Are you sure you want to delete this event?')) {
        deleteEvent(currentEvent.id);
        onClose();
      }
    }
  };

  const handleEdit = () => {
    setMode('edit');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div 
        className="bg-white rounded-lg shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center p-4 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-800">
            {mode === 'add' ? 'Add Event' : mode === 'edit' ? 'Edit Event' : 'Event Details'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4">
          {mode === 'view' && currentEvent ? (
            <EventView 
              event={currentEvent} 
              onEdit={handleEdit} 
              onDelete={handleDelete}
            />
          ) : (
            <EventForm 
              initialDate={modalState.date}
              initialEvent={mode === 'edit' ? currentEvent : undefined}
              onSubmit={handleSubmit}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default EventModal;