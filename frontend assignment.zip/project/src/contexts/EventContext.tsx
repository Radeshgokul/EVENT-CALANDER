import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Event, RecurrencePattern } from '../types';
import { 
  addDays, isSameDay, startOfMonth, endOfMonth, 
  eachDayOfInterval, isSameMonth, isSameWeek 
} from 'date-fns';
import { v4 as uuidv4 } from 'uuid';

interface EventContextType {
  events: Event[];
  addEvent: (event: Omit<Event, 'id'>) => void;
  updateEvent: (event: Event) => void;
  deleteEvent: (id: string) => void;
  getEventsForDate: (date: Date) => Event[];
  moveEvent: (id: string, newDate: Date) => void;
  hasEventConflict: (event: Partial<Event>, excludeId?: string) => boolean;
}

const EventContext = createContext<EventContextType | undefined>(undefined);

export const useEvents = () => {
  const context = useContext(EventContext);
  if (!context) {
    throw new Error('useEvents must be used within an EventProvider');
  }
  return context;
};

interface EventProviderProps {
  children: ReactNode;
}

export const EventProvider: React.FC<EventProviderProps> = ({ children }) => {
  const [events, setEvents] = useState<Event[]>([]);

  // Load events from localStorage on initial render
  useEffect(() => {
    const savedEvents = localStorage.getItem('events');
    if (savedEvents) {
      try {
        const parsedEvents = JSON.parse(savedEvents, (key, value) => {
          if (key === 'date' || key === 'endTime' || key === 'endDate') {
            return value ? new Date(value) : null;
          }
          return value;
        });
        setEvents(parsedEvents);
      } catch (error) {
        console.error('Error parsing saved events', error);
      }
    }
  }, []);

  // Save events to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('events', JSON.stringify(events));
  }, [events]);

  const addEvent = (event: Omit<Event, 'id'>) => {
    const newEvent = {
      ...event,
      id: uuidv4(),
    };
    setEvents((prevEvents) => [...prevEvents, newEvent]);
  };

  const updateEvent = (updatedEvent: Event) => {
    setEvents((prevEvents) =>
      prevEvents.map((event) =>
        event.id === updatedEvent.id ? updatedEvent : event
      )
    );
  };

  const deleteEvent = (id: string) => {
    setEvents((prevEvents) => prevEvents.filter((event) => event.id !== id));
  };

  const expandRecurringEvent = (event: Event, targetDate: Date): Event | null => {
    if (!event.isRecurring || !event.recurrence) return null;
    
    const { type, interval = 1, daysOfWeek, endDate } = event.recurrence;
    const originalDate = new Date(event.date);
    
    // Check if the recurrence has ended
    if (endDate && targetDate > endDate) return null;
    
    // For daily recurrence
    if (type === 'daily') {
      const daysDiff = Math.round((targetDate.getTime() - originalDate.getTime()) / (1000 * 60 * 60 * 24));
      if (daysDiff % interval === 0 && daysDiff > 0) {
        return {
          ...event,
          date: new Date(targetDate),
          endTime: event.endTime ? new Date(targetDate) : undefined,
        };
      }
    }
    
    // For weekly recurrence
    if (type === 'weekly' && daysOfWeek?.includes(targetDate.getDay())) {
      const weeksDiff = Math.floor((targetDate.getTime() - originalDate.getTime()) / (1000 * 60 * 60 * 24 * 7));
      if (weeksDiff % interval === 0 && weeksDiff >= 0) {
        return {
          ...event,
          date: new Date(targetDate),
          endTime: event.endTime ? new Date(targetDate) : undefined,
        };
      }
    }
    
    // For monthly recurrence
    if (type === 'monthly' && targetDate.getDate() === originalDate.getDate()) {
      const monthsDiff = (targetDate.getFullYear() - originalDate.getFullYear()) * 12 + 
                        targetDate.getMonth() - originalDate.getMonth();
      if (monthsDiff % interval === 0 && monthsDiff > 0) {
        return {
          ...event,
          date: new Date(targetDate),
          endTime: event.endTime ? new Date(targetDate) : undefined,
        };
      }
    }
    
    // For custom recurrence
    if (type === 'custom') {
      // Implementation depends on custom rules
      // This is a simple example that repeats every N days
      const daysDiff = Math.round((targetDate.getTime() - originalDate.getTime()) / (1000 * 60 * 60 * 24));
      if (daysDiff % (interval || 1) === 0 && daysDiff > 0) {
        return {
          ...event,
          date: new Date(targetDate),
          endTime: event.endTime ? new Date(targetDate) : undefined,
        };
      }
    }
    
    return null;
  };

  const getEventsForDate = (date: Date): Event[] => {
    // Get single events for this date
    const singleEvents = events.filter(
      (event) => isSameDay(new Date(event.date), date) && !event.isRecurring
    );
    
    // Get recurring events that occur on this date
    const recurringEvents = events
      .filter((event) => event.isRecurring)
      .map((event) => expandRecurringEvent(event, date))
      .filter((event): event is Event => event !== null);
    
    return [...singleEvents, ...recurringEvents];
  };

  const moveEvent = (id: string, newDate: Date) => {
    setEvents((prevEvents) =>
      prevEvents.map((event) => {
        if (event.id === id) {
          // Create a new date with the same time
          const oldDate = new Date(event.date);
          const updatedDate = new Date(newDate);
          updatedDate.setHours(oldDate.getHours());
          updatedDate.setMinutes(oldDate.getMinutes());
          
          // Update endTime if it exists
          let updatedEndTime;
          if (event.endTime) {
            const timeDiff = event.endTime.getTime() - oldDate.getTime();
            updatedEndTime = new Date(updatedDate.getTime() + timeDiff);
          }
          
          return {
            ...event,
            date: updatedDate,
            endTime: updatedEndTime,
          };
        }
        return event;
      })
    );
  };

  const hasEventConflict = (newEvent: Partial<Event>, excludeId?: string): boolean => {
    if (!newEvent.date) return false;
    
    const eventsOnSameDay = getEventsForDate(newEvent.date)
      .filter(event => event.id !== excludeId);
    
    const newEventStart = newEvent.date.getTime();
    const newEventEnd = newEvent.endTime ? newEvent.endTime.getTime() : newEventStart + 3600000; // Default 1 hour
    
    return eventsOnSameDay.some(existingEvent => {
      const existingStart = existingEvent.date.getTime();
      const existingEnd = existingEvent.endTime 
        ? existingEvent.endTime.getTime() 
        : existingStart + 3600000; // Default 1 hour
      
      // Check for overlap
      return (
        (newEventStart >= existingStart && newEventStart < existingEnd) ||
        (newEventEnd > existingStart && newEventEnd <= existingEnd) ||
        (newEventStart <= existingStart && newEventEnd >= existingEnd)
      );
    });
  };

  const value = {
    events,
    addEvent,
    updateEvent,
    deleteEvent,
    getEventsForDate,
    moveEvent,
    hasEventConflict,
  };

  return <EventContext.Provider value={value}>{children}</EventContext.Provider>;
};