export type RecurrenceType = 'none' | 'daily' | 'weekly' | 'monthly' | 'custom';

export interface RecurrencePattern {
  type: RecurrenceType;
  interval?: number; // For custom recurrence, e.g., every 2 weeks
  daysOfWeek?: number[]; // For weekly recurrence, 0 = Sunday, 6 = Saturday
  endDate?: Date | null; // Optional end date for recurring events
}

export interface Event {
  id: string;
  title: string;
  date: Date;
  endTime?: Date;
  description: string;
  color: string; // Event category color
  recurrence: RecurrencePattern;
  isRecurring: boolean;
}

export interface CalendarDay {
  date: Date;
  isCurrentMonth: boolean;
  isToday: boolean;
  events: Event[];
}

export interface EventFormData {
  id: string;
  title: string;
  date: string;
  time: string;
  endTime: string;
  description: string;
  color: string;
  recurrence: RecurrencePattern;
}

export interface ModalState {
  isOpen: boolean;
  mode: 'add' | 'edit' | 'view';
  eventId?: string;
  date?: Date;
}