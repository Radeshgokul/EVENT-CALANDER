import {
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  addMonths,
  subMonths,
  format,
  parse,
} from 'date-fns';
import { CalendarDay } from '../types';

export const generateCalendarDays = (date: Date): CalendarDay[] => {
  const monthStart = startOfMonth(date);
  const monthEnd = endOfMonth(date);
  const calendarStart = startOfWeek(monthStart);
  const calendarEnd = endOfWeek(monthEnd);
  const today = new Date();

  return eachDayOfInterval({
    start: calendarStart,
    end: calendarEnd,
  }).map((day) => ({
    date: day,
    isCurrentMonth: isSameMonth(day, date),
    isToday: isSameDay(day, today),
    events: [],
  }));
};

export const formatDateForDisplay = (date: Date): string => {
  return format(date, 'MMMM yyyy');
};

export const formatDateForInput = (date: Date): string => {
  return format(date, 'yyyy-MM-dd');
};

export const formatTimeForInput = (date: Date): string => {
  return format(date, 'HH:mm');
};

export const parseInputDateTime = (dateString: string, timeString: string): Date => {
  const dateFormat = 'yyyy-MM-dd';
  const timeFormat = 'HH:mm';
  
  // Parse the date
  const parsedDate = parse(dateString, dateFormat, new Date());
  
  // Parse the time
  const timeParts = timeString.split(':').map(Number);
  const hours = timeParts[0] || 0;
  const minutes = timeParts[1] || 0;
  
  // Combine date and time
  const result = new Date(parsedDate);
  result.setHours(hours);
  result.setMinutes(minutes);
  
  return result;
};